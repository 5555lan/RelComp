#pragma once
#include <chrono>
#include <iostream>
#include "Graph.h"
#include "FileIO.h"
#include "MonteCarloSampling.h"
#include "MonteCarloBFS.h"
#include "MonteCarloSamplingDFSSharing.h"
#include "BFSSharing.h"
#include "ConvergenceHelper.h"
#include "RecursiveSampling.h"
#include "Rss.h"
#include "LazyPropagation.h"
#include "MemoryMonitor.h"

// ProbTree
#include <fstream>
#include <stdio.h>
#include <stdlib.h>

#include "definitions.h"
#include "ProbabilisticGraph.h"
#include "TreeDecomposition.h"
#include "ShortestPathHeapSampler.h"
#include "ShortestPathTreeSampler.h"

#define MAX_NODES   2000000

class Menu
{
public:
	Menu();
	~Menu();
	static Graph readGraph();
	static void graphMenu(Graph& graph);
	static void dataMenuNew(std::list<Mapping> mapping_list);
	static void dataMenuExisting(std::list<Mapping> mapping_list);
	static void findKMonteCarlo(Graph& graph);
	static void createMonteCarloBFSSharingFile(Graph& graph);
	static void createBFSHashfile(Graph& graph);
	static void findKBFSSharing(Graph& graph);
	static void findkRecursiveSampling_RB(Graph& graph);
	static void findkRecursiveSampling_RHH(Graph& graph);
	static void findkRSS(Graph& graph);
	static void findkLazyPropagation(Graph& graph);
	static void findkProbTree();
	static void debugCommand(Graph& graph);
};

