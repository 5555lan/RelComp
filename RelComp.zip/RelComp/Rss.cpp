#include "Rss.h"

// Calculates the probabilty of a possible graph
double Rss::piCalculation(DirectedGraph& g, std::vector<Edge_s_t> e, size_t i, std::vector<double>& p_all)
{
	double pi_i = 1.0;
	// Get weight map
	boost::property_map<DirectedGraph, boost::edge_weight_t>::type weights = boost::get(boost::edge_weight_t(), g);

	if (i == 0) {
		for (int j = 0; j < constants::kRSSr; j++) {
			pi_i *= (1 - get(weights, edge(e[j].first, e[j].second, g).first));
			p_all.push_back(get(weights, edge(e[j].first, e[j].second, g).first));
		}
	}
	else {
		pi_i *= get(weights, edge(e[i-1].first, e[i-1].second, g).first);
		for (size_t j = 0; j < i-1; j++) {
			pi_i *= (1 - get(weights, edge(e[j].first, e[j].second, g).first));
		}
	}
	//std::cout << "pi #" << i << ": " << pi_i << std::endl;
	return pi_i;
}

// Gets R edges from g
std::vector<Edge_s_t> Rss::getREdges(const DirectedGraph& g, VertexDescr source, std::set<Edge_s_t> sampled, std::vector<Edge_s_t>& e_all)
{
	std::set<VertexDescr> explored;
	std::queue<VertexDescr> worklist;
	std::vector<Edge_s_t> e;
	Edge_s_t e_curr;
	OutEdgeIter ei, ei_end;
	VertexDescr v, w;
	// Init worklist
	worklist.push(source);
	explored.insert(source);
	while (!worklist.empty() && e.size() < constants::kRSSr) {
		v = worklist.front();
		worklist.pop();
		if (boost::out_degree(v, g) != 0) {
			for (boost::tie(ei, ei_end) = boost::out_edges(v, g); ei != ei_end; ++ei) {
				w = boost::target(*ei, g);
				// Add to e if not sampled
				e_curr = std::make_pair(v, w);
				if (sampled.count(e_curr) == 0) {
					e.push_back(e_curr);
					e_all.push_back(e_curr);
				}
				// Check if r edges found
				if (e.size() == constants::kRSSr) {
					break;
				}
				// if not explored, add to worklist
				if (explored.count(w) == 0) {
					worklist.push(w);
					explored.insert(w);
				}
			}
		}
	}

	return e;
}

// Simplifies the graph given a status vector x i.e. pruning
// Removes all 0 edge cases
Graph Rss::simplifyGraph(const Graph& original_graph, boost::dynamic_bitset<> x, std::vector<Edge_s_t> e)
{
	Graph graph = original_graph;
	size_t end;
	if (x.count() != 0) {
		end = x.find_first();
		// Set weight of sampled existing edge as 1
		boost::remove_edge(e[end].first, e[end].second, *graph.getGraph());
		boost::add_edge(e[end].first, e[end].second, 1, *graph.getGraph());
	}
	else {
		end = constants::kRSSr;
	}
	for (size_t i = 0; i < end; i++) {
		boost::remove_edge(e[i].first, e[i].second, *graph.getGraph());
	}

	return graph;
}

std::set<Edge_s_t> Rss::updateSampled(std::set<Edge_s_t> sampled, std::vector<Edge_s_t> e, int index)
{
	if (index == e.size()) {
		index = e.size() - 1;
	}
	for (int i = 0; i < index + 1; i++) {
		sampled.insert(e[i]);
	}
	return sampled;
}

Rss::Rss()
{
}

double Rss::recursiveStratifiedSampling(Graph& g,const Graph& g1, size_t n, VertexDescr source, VertexDescr target, std::set<Edge_s_t> sampled, std::vector<int> e1, std::vector<int> e2, std::vector<Edge_s_t> e_all, std::vector<double> p_all)
{
	double reliability = 0.0;
	double pi_i, u_i;
	size_t n_i;
	boost::dynamic_bitset<> x;
	std::vector<Edge_s_t> e;
	//Graph g_i;
	std::vector<int> e11 = e1;
	std::vector<int> e22 = e2;


	// Check if threshold reached
	if (n < constants::kRSSThreshold || boost::num_edges(*g.getGraph()) < constants::kRSSr) {
		//std::cout << "n < threshold. Entering Monte Carlo Sampling" << std::endl << std::endl;
		if (n == 0) {
			n = 1;
		}
		//std::cout << "n = " << n << std::endl;

		for (size_t i = 0; i < e11.size();i++)
		{
			boost::remove_edge(e_all[e11[i]].first, e_all[e11[i]].second, *g.getGraph());
		}
		for (size_t i = 0; i < e22.size(); i++) {
			boost::remove_edge(e_all[e22[i]].first, e_all[e22[i]].second, *g.getGraph());
			boost::add_edge(e_all[e22[i]].first, e_all[e22[i]].second, 1, *g.getGraph());
		}

		MonteCarloBFS g_j(*g.getGraph());
		for (size_t j = 0; j < n; j++) {
			// Compute reliability of Gj
			// And update reliability
			//reliability += g_j.run_forRSS(source, target,e11,e22);
			reliability += g_j.run(source, target);
		}


		return reliability / n;
	}
	else {
		// Select r edges from G by BFS strategy
		e = getREdges(*g.getGraph(), source, sampled,e_all);
		// Special Case: Not enough edges
		if (e.size() < constants::kRSSr) {
			//std::cout << "Warning: e.size < r" << std::endl;
			MonteCarloBFS g_j(*g.getGraph());
			for (size_t j = 0; j < n; j++) {
				// Compute reliability of Gj
				// And update reliability
				//reliability += g_j.run_forRSS(source, target,e11,e22);
				reliability += g_j.run(source, target);
			}
			return reliability / n;
		}
		// Case 0
		x = boost::dynamic_bitset<>(constants::kRSSr);
		//g_i = simplifyGraph(g, x, e);
		for (size_t i; i < e.size(); i++) {
			e11.push_back(sampled.size()+i);
		}
		pi_i = piCalculation(*g.getGraph(), e, 0,p_all);
		n_i = pi_i * n;
		u_i = recursiveStratifiedSampling(g, g, n_i, source, target, updateSampled(sampled,e,e.size()),e11,e22,e_all,p_all);
		reliability = reliability + pi_i * u_i;
		// Case 1 to r
		x = boost::dynamic_bitset<>(constants::kRSSr, 1);
		for (int i = 0; i < constants::kRSSr; i++) {
			//g_i = simplifyGraph(g, x, e);
			e11 = e1;
			e22 = e2;
			for (size_t ii; ii < e.size(); ii++) {
				if (i == ii) {
					e22.push_back(sampled.size() + ii);
				}
				else {
					e11.push_back(sampled.size() + ii);
				}
			}
			pi_i = piCalculation(*g.getGraph(), e, x.find_first() + 1,p_all);
			n_i = pi_i * n;
			u_i = recursiveStratifiedSampling(g,g, n_i, source, target, updateSampled(sampled,e,i),e11,e22,e_all,p_all);
			reliability = reliability + pi_i * u_i;
			//std::cout << x << std::endl;
			x <<= 1;
		}
	}
	return reliability;
}

Rss::~Rss()
{
}
