//
//  main.cpp
//  UncertainGraph
//
//  Created by Silviu Maniu on 1/2/13.
//  Copyright (c) 2013 Silviu Maniu. All rights reserved.
//

#include <iostream>
#include <fstream>
#include <sys/time.h>
#include <stdio.h>
#include <stdlib.h>

#include "definitions.h"
#include "ProbabilisticGraph.h"
#include "TreeDecomposition.h"
#include "SPQRDecomposition.h"
#include "ShortestPathHeapSampler.h"
#include "ShortestPathTreeSampler.h"
#include "OptimalSampler.h"
 
#define MAX_NODES   2000000

void add_nodes_from(NodeIdType original_node, ProbabilisticGraph* graph, std::vector<NodeIdType>* queue, std::unordered_set<NodeIdType>* visited){
    std::unordered_map<NodeIdType, EdgeType*>* outgoing = graph->get_outgoing_nodes(original_node);
    for(auto node_tuple:*outgoing){
        NodeIdType node = node_tuple.first;
        if(visited->find(node)==visited->end()){
            queue->push_back(node);
            visited->insert(node);
        }
    }
}

void decompose(int, const char * argv[]){
    std::cout << "loading graph... ";
    timestamp_t t0 = get_timestamp();
    std::ifstream file(argv[2]);
    ProbabilisticGraph graph(file);
    timestamp_t t1 = get_timestamp();
    float time_msec = (t1-t0)/1000.0L;
    std::cout << "nodes " << graph.get_number_nodes() << " edges " << graph.get_number_edges() << std::endl;
    std::cout << "time for loading (msec) " << time_msec << "\n";
    TreeDecomposition decomposition(&graph);
    decomposition.decompose_graph(atoi(argv[3]));
}

void spqr(int argc, const char * argv[]){
    std::cout << "loading graph... ";
    timestamp_t t0 = get_timestamp();
    std::ifstream file(argv[2]);
    ProbabilisticGraph graph(file);
    timestamp_t t1 = get_timestamp();
    float time_msec = (t1-t0)/1000.0L;
    std::cout << "nodes " << graph.get_number_nodes() << " edges " << graph.get_number_edges() << std::endl;
    std::cout << "time for loading (msec) " << time_msec << "\n";
    std::string file_name_dec(argv[3]);
    int samples = 10000;
    if(argc>4)
        samples = atoi(argv[4]);
    SPQRDecomposition decomposition(&graph,file_name_dec,samples);
    decomposition.decompose_graph();
}

void sampletree(int argc, const char * argv[]){
    std::cout << "loading transformation from ./" << argv[2] << "... " << std::flush;
    timestamp_t t0 = get_timestamp();
    std::string file_name_decomp(argv[2]);
    TreeDecomposition decomp(file_name_decomp);
    Bag* root_bag = decomp.get_root();
    timestamp_t t1 = get_timestamp();
    float time_msec = (t1-t0)/1000.0L;
    float time_prop = 0;
	float total_time = 0;
    std::cout << "done in " << time_msec << "(msec)" << std::endl;
    std::string file_name_pairs(argv[3]);
    int samples = 1000;
    std::ifstream file(argv[4]);
    t0 = get_timestamp();
    ProbabilisticGraph graph(file);
    t1 = get_timestamp();
    time_msec = (t1-t0)/1000.0L;
    if(argc>5)
        samples = atoi(argv[5]);
    std::ifstream file_pairs(file_name_pairs);
    NodeIdType source, target;
    int pairs = 0;
    std::cout << "sampling pairs" << std::endl;
    ShortestPathTreeSampler sampler;
    ProbabilisticGraph *pgraph = &graph;
    sampler.set_graph(pgraph);
    int sampled_computed = 0;
    int sampled_original = 0;
	double total_reliability = 0;
	double reliability = 0;
    while(file_pairs>>source>>target){
        pairs++;
        NodeIdType src,tgt;
        t0 = get_timestamp();
        src = tgt = -1;
        if(!root_bag->has_node(source)) src=source;
        if(!root_bag->has_node(target)) tgt=target;
        int hit_bags = 0;
        if((src!=-1)||(tgt!=-1)) hit_bags=decomp.redo_computations(src,tgt);
        //decomp.write_decomposition();
        std::cout << source << "\t" << target << std::endl << std::flush;
        //std::cout << root_bag->get_number_computed_edges() << std::endl << std::flush;
        //std::cout << hit_bags << std::endl << std::flush;
        t1 = get_timestamp();
        time_prop=(t1-t0)/1000.0L;
        t0 = get_timestamp();
        DistanceDistribution* dist = sampler.sample(root_bag, source, target, samples);
        t1 = get_timestamp();
        time_msec=(t1-t0)/1000.0L;
        //std::cout << *dist << std::flush;
        sampled_computed=sampler.get_sampled_computed();
        sampled_original=sampler.get_sampled_original();
		reliability = sampler.get_reached() / (double)samples;
        //std::cout << time_prop << std::endl;
        //std::cout << time_msec << std::endl;
		std::cout << "Time taken (ms): " << time_prop + time_msec << std::endl;
        std::cout << sampled_original << std::endl;
        std::cout << sampled_computed << std::endl;
		std::cout << "Reliability: " << reliability << std::endl;
		total_reliability += reliability;
		total_time += time_prop + time_msec;
    }
	std::cout << "Avg R = " << total_reliability / (double) pairs << std::endl;
	std::cout << "Avg t (s) = " << total_time / (double)pairs / 1000.0L << std::endl;
    file_pairs.close();
}

void sample(int argc, const char * argv[]){
    //std::cout << "loading transformation from ./" << argv[2] << "... " << std::flush;
    timestamp_t t0 = get_timestamp();
    std::string file_name_decomp(argv[2]);
    TreeDecomposition decomp(file_name_decomp);
    Bag* root_bag = decomp.get_root();
    timestamp_t t1 = get_timestamp();
    float time_msec = (t1-t0)/1000.0L;
    float time_prop = 0;
	float total_time = 0;
    //std::cout << "done in " << time_msec << "(msec)" << std::endl;
    std::string file_name_pairs(argv[3]);
    int samples = 1000;
    if(argc>4)
        samples = atoi(argv[4]);
    std::ifstream file_pairs(file_name_pairs);
    NodeIdType source, target;
    int pairs = 0;
    //std::cout << "sampling pairs" << std::endl;
    ShortestPathSampler sampler;
    int sampled_computed = 0;
    int sampled_original = 0;
	double reliability = 0;
	double total_reliability = 0;
    while(file_pairs>>source>>target){
        pairs++;
        NodeIdType src,tgt;
        t0 = get_timestamp();
        src = tgt = -1;
        bool good_tree = true;
        if(!root_bag->has_node(source)) src=source;
        if(!root_bag->has_node(target)) tgt=target;
        int hit_bags = 0;
        try {
            if((src!=-1)||(tgt!=-1)) hit_bags=decomp.redo_computations(src,tgt);
        }
        catch(int e){
            std::cerr << "exception " << e << "caught in " << src << "->" <<\
            tgt << " - skipping" << std::endl;
            good_tree=false;
        }
        //decomp.write_decomposition();
        std::cout << "s-t pairs: " << source << "\t" << target << std::endl << std::flush;
        //std::cout << root_bag->get_number_computed_edges() << std::endl << std::flush;
        //std::cout << hit_bags << std::endl << std::flush;
        t1 = get_timestamp();
        time_prop=(t1-t0)/1000.0L;
        t0 = get_timestamp();
        DistanceDistribution *dist = nullptr;
        if(good_tree){
            try{
                dist = sampler.sample(root_bag, source, target, samples);
            }
            catch(int e){
                std::cerr << "exception " << e << "caught in " << src << "->"\
                << tgt << " - skipping" << std::endl;
                dist = new DistanceDistribution();
            }
        }
        else
            dist = new DistanceDistribution();
        t1 = get_timestamp();
        time_msec=(t1-t0)/1000.0L;
        //std::cout << *dist << std::flush;
        sampled_computed=sampler.get_sampled_computed();
        sampled_original=sampler.get_sampled_original();
		reliability = sampler.get_reached() / (double)samples;
        //std::cout << time_prop << std::endl;
        //std::cout << time_msec << std::endl;
		std::cout << "Time taken (ms):" << time_prop + time_msec << std::endl;
        std::cout << sampled_original << std::endl;
        std::cout << sampled_computed << std::endl;
		std::cout << "Reliability: " << reliability << std::endl;
		total_reliability += reliability;
		total_time += time_prop + time_msec;
    }
	std::cout << "Avg R = " << total_reliability / (double)pairs << std::endl;
	std::cout << "Avg t (s) = " << total_time / (double)pairs / 1000.0L << std::endl;
    file_pairs.close();
}


void pworld(int argc, const char * argv[]){
    //std::cout << "loading transformation from ./" << argv[2] << "... " << std::flush;
    timestamp_t t0 = get_timestamp();
    std::string file_name_decomp(argv[2]);
    TreeDecomposition decomp(file_name_decomp);
    Bag* root_bag = decomp.get_root();
    timestamp_t t1 = get_timestamp();
    float time_msec = (t1-t0)/1000.0L;
    //std::cout << "done in " << time_msec << "(msec)" << std::endl;
    std::string file_name_pairs(argv[3]);
    std::ifstream file_pairs(file_name_pairs);
    NodeIdType source, target;
    double pairs = 0;
    double pworlds = 0;
    //std::cout << "sampling pairs" << std::endl;
	 int samples = 1000;
    if(argc>4)
        samples = atoi(argv[4]);
    OptimalSampler sampler;
    while(file_pairs>>source>>target){
        pairs += 1.;
        NodeIdType src,tgt;
        t0 = get_timestamp();
        src = tgt = -1;
        if(!root_bag->has_node(source)) src=source;
        if(!root_bag->has_node(target)) tgt=target;
        if((src!=-1)||(tgt!=-1))
            decomp.redo_computations(src,tgt);
        double pworld = root_bag->get_possible_worlds();
        t1 = get_timestamp();
        pworlds += pworld;
        time_msec=(t1-t0)/1000.0L;
        //std::cout << pworld << std::endl << std::flush;
    }
    std::cout << pworlds/pairs << std::endl << std::flush;
	std::cout << "Time taken (ms):" << time_msec << std::endl;
}

void optsample(int argc, const char * argv[]){
    //std::cout << "loading transformation from ./" << argv[2] << "... " << std::flush;
    timestamp_t t0 = get_timestamp();
    std::string file_name_decomp(argv[2]);
    TreeDecomposition decomp(file_name_decomp);
    Bag* root_bag = decomp.get_root();
    timestamp_t t1 = get_timestamp();
    float time_msec = (t1-t0)/1000.0L;
    //std::cout << "done in " << time_msec << "(msec)" << std::endl;
    std::string file_name_pairs(argv[3]);
    double eps = 0.05;
    double del = 0.05;
    if(argc>4)
        eps = atof(argv[4]);
    if(argc>5)
        del = atof(argv[5]);
    std::ifstream file_pairs(file_name_pairs);
    NodeIdType source, target;
    double pairs = 0;
    double samples = 0;
    //std::cout << "sampling pairs" << std::endl;
    OptimalSampler sampler;
    while(file_pairs>>source>>target){
        pairs += 1.;
        NodeIdType src,tgt;
        t0 = get_timestamp();
        src = tgt = -1;
        if(!root_bag->has_node(source)) src=source;
        if(!root_bag->has_node(target)) tgt=target;
        int hit_bags = 0;
        if((src!=-1)||(tgt!=-1)) hit_bags=decomp.redo_computations(src,tgt);
        //decomp.write_decomposition();
        //std::cout << source << "\t" << target << std::endl << std::flush;
        samples += sampler.find_optimal_samples(root_bag, source, target, eps, del);
        t1 = get_timestamp();
        time_msec=(t1-t0)/1000.0L;
        //std::cout << samples << std::endl << std::flush;
    }
    std::cout << eps << "\t" << del << "\t" << (unsigned long)(samples/pairs) << std::endl << std::flush;
    file_pairs.close();
}

int main(int argc, const char * argv[])
{
    std::string first_arg(argv[1]);
    if(first_arg=="--decompose") decompose(argc, argv);
    else if(first_arg=="--spqr") spqr(argc, argv);
    else if(first_arg=="--sample") sample(argc, argv);
    else if(first_arg=="--sampletree") sampletree(argc, argv);
    else if(first_arg=="--optimal") optsample(argc, argv);
    else if(first_arg=="--pworld") pworld(argc, argv);
}

