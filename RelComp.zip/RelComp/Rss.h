#pragma once
#include <boost/dynamic_bitset.hpp>
#include <queue>
#include "Common.h"
#include "Constants.h"
#include "MonteCarloBFS.h"
#include "Graph.h"

class Rss
{
private:
	double piCalculation(DirectedGraph& g, std::vector<Edge_s_t> e, size_t i, std::vector<double>& p_all);
	std::vector<Edge_s_t> getREdges(const DirectedGraph& g, VertexDescr source, std::set<Edge_s_t> sampled, std::vector<Edge_s_t>& e_all);
	Graph simplifyGraph(const Graph& original_graph, boost::dynamic_bitset<> x, std::vector<Edge_s_t> e);
	std::set<Edge_s_t> updateSampled(std::set<Edge_s_t> sampled, std::vector<Edge_s_t> e, int index);
public:
	Rss();
	double recursiveStratifiedSampling(Graph& g, const Graph& g1, size_t n, VertexDescr source, VertexDescr target, std::set<Edge_s_t> sampled, std::vector<int> e1, std::vector<int> e2, std::vector<Edge_s_t> e_all, std::vector<double> p_all);
	~Rss();
};

