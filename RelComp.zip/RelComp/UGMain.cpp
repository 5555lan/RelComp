#pragma once
#include <iostream>
#include "Menu.h"
#include "FileIO.h"

int main(int argc, char* argv[]) {
	// Variables
	int option = 0;

	// Set dir_path
	if (argc > 1) {
		std::cout << "Setting working directory to " << argv[1] << std::endl << std::endl;
		FileIO::setDirPath(argv[1]);
	}
	else {
		// Set to default
		FileIO::setDirPath(".\\");
	}

	// Main Menu
	while (option != 9) {
		std::cout << "1. Read file, edit and save new Dataset (Disregard existing edge probabilities)" << std::endl;
		std::cout << "2. Read file, edit and save new Dataset (Inherit edge probabilities)" << std::endl;
		std::cout << "3. Process DBLP file (Creates a probability output)" << std::endl;
		std::cout << "4. Load graph from file" << std::endl;
		std::cout << "5. Find k for ProbTree" << std::endl;
		std::cout << "9. Terminate" << std::endl;
		std::cout << "Option: ";
		std::cin >> option;

		switch (option) {
		case 1:
			// Gets user input on a file and reads into memory
			// For hep.txt
			std::cout << "Reading file" << std::endl;
			Menu::dataMenuNew(FileIO::readFile(FileIO::getFilePath()));
			break;
		case 2:
			// Gets user input on a file and reads into memory
			// Any other undirected datsets
			std::cout << "Reading file" << std::endl;
			Menu::dataMenuExisting(FileIO::readFile(FileIO::getFilePath(),1));
			break;
		case 3:
			// Gets user input on a file and 
			// Reads DBLP datset
			// Processes DBLP dataset based on its format <Node1> <Node2> <Probability> <Int> <Probability> <Int> ...
			// Opens data menu for further processing (E.g. Directed -> Undirected)
			std::cout << "Reading file" << std::endl;
			Menu::dataMenuExisting(FileIO::readDBLPFile(FileIO::getFilePath()));
			break;
		case 4:
		{
			Graph g = Menu::readGraph();
			Menu::graphMenu(g);
		}
			break;
		case 5:
			Menu::findkProbTree();
			break;
		case 9:
			std::cout << "Exiting program..." << std::endl;
			break;
		default:
			std::cout << "Invalid input. Please try again." << std::endl;
			break;
		}
	}

	return 0;
}