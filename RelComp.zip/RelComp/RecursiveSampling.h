#pragma once
#include <stack>
#include <queue>
#include "Common.h"
#include "Graph.h"
#include "MonteCarloBFS.h"
#include "Randomiser.h"
class RecursiveSampling
{
private:
	boost::property_map<DirectedGraph, boost::edge_weight_t>::type weights;
	Graph reference_graph;
	DirectedGraph dg;
	VertexDescr t;
	std::queue<Edge_s_t> getOutgoingNeighbours(VertexDescr v);
public:
	RecursiveSampling();
	RecursiveSampling(Graph graph);
	double findReliability_RB(Graph& g, std::set<Edge_s_t> e1, std::set<Edge_s_t> e2, std::stack<VertexDescr> sv, std::stack<std::queue<Edge_s_t>> si, size_t n);
	double findReliability_RHH(std::set<Edge_s_t> e1, std::set<Edge_s_t> e2, std::stack<VertexDescr> sv, std::stack<std::queue<Edge_s_t>> si, size_t n);
	std::pair<std::stack<VertexDescr>, std::stack<std::queue<Edge_s_t>>> getInitStack(VertexDescr source);
	std::pair<Edge_s_t, bool> nextEdge(std::set<Edge_s_t> e1, std::set<Edge_s_t> e2, std::stack<VertexDescr> sv, std::stack<std::queue<Edge_s_t>> si);
	void setTarget(VertexDescr target);
	double samplingR(std::set<Edge_s_t> e1, std::set<Edge_s_t> e2, VertexDescr v, double pr, double q);
	~RecursiveSampling();
};

