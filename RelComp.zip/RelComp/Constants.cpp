#include "Constants.h"

namespace constants {
	const double kRecursiveSamplingThreshold = 5;
	const size_t kRSSr = 50;
	const size_t kRSSThreshold = 10;	// 10
	//const int kMaximumRound = 10000;
	const int kMaximumRound = 5000;
	const int kKStepUp = 250;
	//const int kRepeatForVariance = 100;
	const int kRepeatForVariance = 100;
	const double kReliabilityThreshold = -1;//0.0001;
}