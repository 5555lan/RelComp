#include "Menu.h"

Menu::Menu()
{
}


Menu::~Menu()
{
}

Graph Menu::readGraph()
{
	// Get input on file path on graph
	std::string file_path = FileIO::getFilePath();
	std::list<Mapping> mapping_list = FileIO::readFile(file_path, 1);

	std::cout << "Loading graph...";

	// Init graph
	Graph g(mapping_list, file_path);

	std::cout << "Done" << std::endl;
	return g;
}

void Menu::graphMenu(Graph & graph)
{
	int option = 0;

	while (option != 99) {
		// Graph Menu
		std::cout << std::endl;
		std::cout << "0. Load another graph" << std::endl;
		std::cout << "1. Print edge list" << std::endl;
		std::cout << "2. Print graph to Graphviz" << std::endl;
		std::cout << "3. Generate 100 random unique source-target pairs" << std::endl;
		std::cout << "4. Find Optimal K for Monte Carlo Sampling (BFS)" << std::endl;
		std::cout << "5. Generate BFS Sharing data file" << std::endl;
		std::cout << "6. BFS Sharing: Generate hash file" << std::endl;
		std::cout << "7. Find Optimal K for BFS Sharing" << std::endl;
		//std::cout << "8. Find Optimal K for Recursive Sampling (RB)" << std::endl;
		std::cout << "8. Find Optimal K for Recursive Sampling (RHH)" << std::endl;
		std::cout << "9. Find Optimal K for Recursive Stratified Sampling" << std::endl;
		std::cout << "10. Find Optimal K for Lazy Propagation Sampling" << std::endl;
		std::cout << "11. Graph Properties" << std::endl;
		std::cout << "99. Exit to Main Menu" << std::endl;
		std::cout << "Option: ";
		std::cin >> option;
		switch (option) {
		case 0:
			// Load graph
		{
			Graph g = Menu::readGraph();
			Menu::graphMenu(g);
		}
			option = 99;	// End while loop
			break;
		case 1:
			// Print Edge List
			graph.printEdgeList();
			break;
		case 2:
			// Print graph to Graphviz
			graph.printGraph();
			break;
		case 3:
			// Generates 100 unique source-target pairs and save into a file
			FileIO::saveFile(graph.getKUniquePairsSourceTargetVertices(100, 2, *graph.getGraph())); //2
			//FileIO::saveFile(graph.getKUniquePairsSourceTargetVertices(100, 4, *graph.getGraph())); //4
			//FileIO::saveFile(graph.getKUniquePairsSourceTargetVertices(100, 6, *graph.getGraph()));	//6
			break;
		case 4:
			Menu::findKMonteCarlo(graph);
			break;
		case 5:
			Menu::createMonteCarloBFSSharingFile(graph);
			break;
		case 6:
			Menu::createBFSHashfile(graph);
			break;
		case 7:
			Menu::findKBFSSharing(graph);
			break;
		//case 8:
			//Menu::findkRecursiveSampling_RB(graph);
			//break;
		case 8:
			Menu::findkRecursiveSampling_RHH(graph);
			break;
		case 9:
			Menu::findkRSS(graph);
			break;
		case 10:
			Menu::findkLazyPropagation(graph);
			break;
		case 11:
			std::cout << std::endl;
			std::cout << "Graph: " << graph.getGraphName() << std::endl;
			graph.printStats();
			break;
		// Debug Commands
		case 98:
			// Debug
			Menu::debugCommand(graph);
			break;
		case 99:
			break;
		default:
			std::cout << "Invalid input. Please try again." << std::endl;
			break;
		}
	}
}

// Will disregard old proabilities in file
void Menu::dataMenuNew(std::list<Mapping> mapping_list)
{
	int option = 0;

	while (option != 9) {
		// Dataset Menu
		std::cout << std::endl;
		std::cout << "0. Load another file" << std::endl;
		std::cout << "1. Generate edge probabilities" << std::endl;
		std::cout << "9. Exit to Main Menu" << std::endl;
		std::cout << "Option: ";
		std::cin >> option;

		switch (option) {
		case 0:
			// Get new file to load into memory
			mapping_list = FileIO::readFile(FileIO::getFilePath());
			break;
		case 1:
			// Gets user input on probabilities to generate and save a new file
			FileIO::saveFile(mapping_list);
			break;
		case 9:
			break;
		default:
			std::cout << "Invalid input. Please try again." << std::endl;
			break;
		}
	}
}

// Uses existing probabilities in file
void Menu::dataMenuExisting(std::list<Mapping> mapping_list)
{
	int option = 0;

	while (option != 9) {
		// Dataset Menu
		std::cout << std::endl;
		std::cout << "0. Load another file" << std::endl;
		std::cout << "1. Generate edge probabilities" << std::endl;
		std::cout << "9. Exit to Main Menu" << std::endl;
		std::cout << "Option: ";
		std::cin >> option;

		switch (option) {
		case 0:
			// Get new file to load into memory
			mapping_list = FileIO::readFile(FileIO::getFilePath(), 1);
			break;
		case 1:
			// Gets user input on probabilities to generate and save a new file
			FileIO::saveFile(mapping_list);
			break;
		case 9:
			break;
		default:
			std::cout << "Invalid input. Please try again." << std::endl;
			break;
		}
	}
}

void Menu::findKMonteCarlo(Graph & graph)
{
	std::cout << std::endl;
	std::cout << "Init Monte Carlo Sampling (Finding K)..." << std::endl;
	int num_reached = 0;
	int k = 0;	
	double reliability;
	std::vector<double> reliability_k, reliability_j;
	double curr_avg_r = 2.0;
	double prev_avg_r = 3.0;
	double avg_r = 0.0;
	double diff_sq_sum = 0.0;
	bool write_flag = true;
	VertexDescr source, target;
	std::pair<VertexDescr, VertexDescr> source_target_pair;
	MonteCarloBFS g_j(*graph.getGraph());

	// Get the respective source-target pairs list from user input
	std::cout << std::endl << "Reading Source-Target file..." << std::endl;
	std::vector<std::pair<VertexDescr, VertexDescr>> source_target_pairs = FileIO::readSourceTargetFile(FileIO::getFilePath());

	MemoryMonitor mm = MemoryMonitor();
	std::thread t1(&MemoryMonitor::updatePeakMemory, std::ref(mm));
	t1.detach();
	
	//std::cout << "Run for k = ";
	//std::cin >> k;
	//int k_limit = k;
	//k -= constants::kKStepUp;
	

	while (/*k < k_limit*/ fabs(curr_avg_r - prev_avg_r) > constants::kReliabilityThreshold && k < constants::kMaximumRound) {
		// Step up k
		k += constants::kKStepUp;
		std::cout << std::endl << "k = " << k << std::endl;

		// Reset var
		reliability_k.clear();

		for (size_t i = 0; i < source_target_pairs.size(); i++) {
			source_target_pair = source_target_pairs[i];
			source = source_target_pair.first;
			target = source_target_pair.second;

			// Reset var
			reliability_j.clear();
			diff_sq_sum = 0.0;
			write_flag = true;
			auto total_duration = 0;

			for (int j = 0; j < constants::kRepeatForVariance; j++) {
				std::cout << j << "th iteration" << std::endl;
				// Reset initial conditions
				num_reached = 0;

				// Start time
				auto start = std::chrono::high_resolution_clock::time_point::max();
				auto finish = std::chrono::high_resolution_clock::time_point::max();
				start = std::chrono::high_resolution_clock::now();
				mm.startMonitoring();

				// Run this in parallel, multi-core support
#pragma omp parallel for num_threads(1)
				for (int i = 0; i < k; i++) {
					num_reached = num_reached + g_j.run(source, target);
				}

				// Calculate reliability
				reliability = num_reached / (double)k;

				// Stop time
				finish = std::chrono::high_resolution_clock::now();
				//auto duration = std::chrono::duration_cast<std::chrono::seconds>(finish - start).count();
				auto duration = std::chrono::duration_cast<std::chrono::milliseconds>(finish - start).count();

				std::cout << "Reliability Estimator, R^ (" << source << ", " << target << ") = " << reliability << std::endl;
				std::cout << "Execution time = " << duration << " ms" << std::endl << std::endl;

				// Add r to vector
				reliability_j.push_back(reliability);
				total_duration += duration;

				if (j == constants::kRepeatForVariance - 1) {
					// Write interim results into csv
					avg_r = ConvergenceHelper::getAvgReliability(reliability_j);
					FileIO::appendResultstoFile(k, avg_r, total_duration/ constants::kRepeatForVariance, mm.getPeakMemory(), graph.getGraphName() + "_MonteCarlo_k_" + std::to_string(i) + ".csv");
					write_flag = false;
				}
				
			}

			// Add r to vector of r
			reliability_k.push_back(avg_r);

			// Variance calculation
			avg_r = ConvergenceHelper::getAvgReliability(reliability_j);
			for (int j = 0; j < constants::kRepeatForVariance; j++) {
				auto difference_sq = pow(reliability_j[j] - avg_r, 2);
				diff_sq_sum += difference_sq;
			}
			FileIO::appendResultstoFile(k, diff_sq_sum / (constants::kRepeatForVariance - 1), 0, i, graph.getGraphName() + "_MC_variance.csv");

		}
		// Calulate avg r
		prev_avg_r = curr_avg_r;
		curr_avg_r = ConvergenceHelper::getAvgReliability(reliability_k);
	}
	mm.stopMonitoring();
}

/*
 * Generates a set number of BFS Sharing files
 */
void Menu::createMonteCarloBFSSharingFile(Graph & graph)
{
	int k = 0;
	bool write_flag = true;

	MemoryMonitor mm = MemoryMonitor();
	std::thread t1(&MemoryMonitor::updatePeakMemory, std::ref(mm));
	t1.detach();
	
	while (k < constants::kMaximumRound)
	{
		k += constants::kKStepUp;
		write_flag = true;

		for (int j = 0; j < constants::kRepeatForVariance; j++) {
			std::cout << j << "th iteration" << std::endl;

			// Start time
			auto start = std::chrono::high_resolution_clock::time_point::max();
			auto finish = std::chrono::high_resolution_clock::time_point::max();
			start = std::chrono::high_resolution_clock::now();
			mm.startMonitoring();

			BFSSharing g(graph, k, j);

			// Stop time
			finish = std::chrono::high_resolution_clock::now();
			auto duration = std::chrono::duration_cast<std::chrono::seconds>(finish - start).count();
			std::cout << std::endl << "k = " << k << std::endl;
			std::cout << "Execution time = " << duration << " s" << std::endl;

			if (write_flag) {
				FileIO::appendResultstoFile(k, 0.0, duration, mm.getPeakMemory(), graph.getGraphName() + "_BFSSharing_OfflineMap_k.csv");
				write_flag = false;
			}
		}
	}
	mm.stopMonitoring();
}

void Menu::createBFSHashfile(Graph & graph)
{
	std::cout << "> BFS Sharing Hash File Generation <" << std::endl;
	std::cout << "Reading BFS Map..." << std::endl;
	std::string index_file_name = FileIO::getFilePath();
	BFSSharing::generateHashFile(graph, index_file_name);
}

void Menu::findkRecursiveSampling_RB(Graph & graph)
{
	VertexDescr source, target;
	DirectedGraph g(*graph.getGraph());
	RecursiveSampling rs(graph);
	size_t k = 0;
	double reliability = 0.0;
	std::vector<double> reliability_k;
	double curr_avg_r = 2.0;
	double prev_avg_r = 3.0;
	// Get the respective source-target pairs list from user input
	std::cout << std::endl << "Reading Source-Target file..." << std::endl;
	std::vector<std::pair<VertexDescr, VertexDescr>> source_target_pairs = FileIO::readSourceTargetFile(FileIO::getFilePath());

	// Start up Memory Monitor daemon thread
	MemoryMonitor mm = MemoryMonitor();
	std::thread t1(&MemoryMonitor::updatePeakMemory, std::ref(mm));
	t1.detach();

	while (fabs(curr_avg_r - prev_avg_r) > constants::kReliabilityThreshold && k < constants::kMaximumRound) {
		// Step up k
		k += constants::kKStepUp;
		std::cout << std::endl << "k = " << k << std::endl;

		// Reset var
		reliability_k.clear();

		for (size_t i = 0; i < source_target_pairs.size(); i++) {
			source = source_target_pairs[i].first;
			target = source_target_pairs[i].second;

			// Set target
			rs.setTarget(target);
			/*rs.updateReachable(g, source);*/

			// Init sv and si
			auto p = rs.getInitStack(source);

			// Start time
			auto start = std::chrono::high_resolution_clock::time_point::max();
			auto finish = std::chrono::high_resolution_clock::time_point::max();
			start = std::chrono::high_resolution_clock::now();
			mm.startMonitoring();

			// Calculate reliability
			reliability = rs.findReliability_RB(graph, std::unordered_set<Edge_s_t, pair_hash>(), std::unordered_set<Edge_s_t, pair_hash>(), p.first, p.second, k);

			// Stop time
			finish = std::chrono::high_resolution_clock::now();
			//auto duration = std::chrono::duration_cast<std::chrono::seconds>(finish - start).count();
			auto duration = std::chrono::duration_cast<std::chrono::milliseconds>(finish - start).count();

			std::cout << "Reliability Estimator, R^ (" << source << ", " << target << ") = " << reliability << std::endl;
			std::cout << "Execution time = " << duration << " ms" << std::endl << std::endl;
			// Write interim results into csv
			FileIO::appendResultstoFile(k, reliability, duration, mm.getPeakMemory(), graph.getGraphName() + "_RecursiveSampling_k_" + std::to_string(i) + ".csv");

			// Add r to vector of r
			reliability_k.push_back(reliability);
		}
		// Calulate avg r
		prev_avg_r = curr_avg_r;
		curr_avg_r = ConvergenceHelper::getAvgReliability(reliability_k);
	}
	mm.stopMonitoring();
}

void Menu::findkRecursiveSampling_RHH(Graph & graph)
{
	VertexDescr source, target;
	DirectedGraph g(*graph.getGraph());
	RecursiveSampling rs(graph);
	size_t k = 0;
	double reliability = 0.0;
	std::vector<double> reliability_k, reliability_j;
	double curr_avg_r = 2.0;
	double prev_avg_r = 3.0;
	double avg_r = 0.0;
	double diff_sq_sum = 0.0;
	bool write_flag = true;
	// Get the respective source-target pairs list from user input
	std::cout << std::endl << "Reading Source-Target file..." << std::endl;
	std::vector<std::pair<VertexDescr, VertexDescr>> source_target_pairs = FileIO::readSourceTargetFile(FileIO::getFilePath());

	// Start up Memory Monitor daemon thread
	MemoryMonitor mm = MemoryMonitor();
	std::thread t1(&MemoryMonitor::updatePeakMemory, std::ref(mm));
	t1.detach();

	while (fabs(curr_avg_r - prev_avg_r) > constants::kReliabilityThreshold && k < constants::kMaximumRound) {
		// Step up k
		k += constants::kKStepUp;
		std::cout << std::endl << "k = " << k << std::endl;

		// Reset var
		reliability_k.clear();

		for (size_t i = 0; i < source_target_pairs.size(); i++) {
			source = source_target_pairs[i].first;
			target = source_target_pairs[i].second;

			//RecursiveSampling rs(graph);
			// Set target
			rs.setTarget(target);
			/*rs.updateReachable(g, source);*/

			// Reset var
			reliability_j.clear();
			diff_sq_sum = 0.0;
			write_flag = true;
			auto total_duration = 0;

			for (int j = 0; j < constants::kRepeatForVariance; j++) {
				std::cout << j << "th iteration" << std::endl;

				// Init sv and si
				auto p = rs.getInitStack(source);
				std::unordered_set<VertexDescr> ini_sv_map;
				ini_sv_map.insert(source);
				//std::cout <<"count of neighbors:"<< p.second.size()<<std::endl;


				// Start time
				auto start = std::chrono::high_resolution_clock::time_point::max();
				auto finish = std::chrono::high_resolution_clock::time_point::max();
				start = std::chrono::high_resolution_clock::now();
				mm.startMonitoring();

				// Calculate reliability
				reliability = rs.findReliability_RHH(std::unordered_set<Edge_s_t, pair_hash>(), std::unordered_set<Edge_s_t, pair_hash>(), p.first, ini_sv_map, p.second, k);

				// Stop time
				finish = std::chrono::high_resolution_clock::now();
				//auto duration = std::chrono::duration_cast<std::chrono::seconds>(finish - start).count();
				auto duration = std::chrono::duration_cast<std::chrono::milliseconds>(finish - start).count();
				total_duration += duration;

				std::cout << "Reliability Estimator, R^ (" << source << ", " << target << ") = " << reliability << std::endl;
				std::cout << "Execution time = " << duration << " ms" << std::endl << std::endl;

				

				// Add r to vector
				reliability_j.push_back(reliability);

				if (j== constants::kRepeatForVariance-1) {
					// Write interim results into csv
					avg_r = ConvergenceHelper::getAvgReliability(reliability_j);
					FileIO::appendResultstoFile(k, avg_r, total_duration/ constants::kRepeatForVariance, mm.getPeakMemory(), graph.getGraphName() + "_RecursiveSampling_RHH_" + std::to_string(i) + ".csv");
					write_flag = false;
				}
			}

			// Add r to vector of r			
			reliability_k.push_back(avg_r);

			// Variance calculation
			avg_r = ConvergenceHelper::getAvgReliability(reliability_j);
			for (int j = 0; j < constants::kRepeatForVariance; j++) {
				auto difference_sq = pow(reliability_j[j] - avg_r, 2);
				diff_sq_sum += difference_sq;
			}
			FileIO::appendResultstoFile(k, diff_sq_sum / (constants::kRepeatForVariance - 1), 0, i, graph.getGraphName() + "_RecursiveSampling_RHH_variance.csv");
		}
		// Calulate avg r
		prev_avg_r = curr_avg_r;
		curr_avg_r = ConvergenceHelper::getAvgReliability(reliability_k);
	}
	mm.stopMonitoring();
}

void Menu::findkRSS(Graph & graph)
{
	VertexDescr source, target;
	DirectedGraph g(*graph.getGraph());
	Rss rss;
	size_t k = 0;	
	double reliability = 0.0;
	std::vector<double> reliability_k, reliability_j;
	double curr_avg_r = 2.0;
	double prev_avg_r = 3.0;
	double avg_r = 0.0;
	double diff_sq_sum = 0.0;
	bool write_flag = true;
	// Get the respective source-target pairs list from user input
	std::cout << std::endl << "Reading Source-Target file..." << std::endl;
	std::vector<std::pair<VertexDescr, VertexDescr>> source_target_pairs = FileIO::readSourceTargetFile(FileIO::getFilePath());

	// Start up Memory Monitor daemon thread
	MemoryMonitor mm = MemoryMonitor();
	std::thread t1(&MemoryMonitor::updatePeakMemory, std::ref(mm));
	t1.detach();

	while (fabs(curr_avg_r - prev_avg_r) > constants::kReliabilityThreshold && k < constants::kMaximumRound) {
		// Step up k
		k += constants::kKStepUp;
		std::cout << std::endl << "k = " << k << std::endl;

		// Reset var
		reliability_k.clear();

		for (size_t i = 0; i < source_target_pairs.size(); i++) {
			source = source_target_pairs[i].first;
			target = source_target_pairs[i].second;

			// Reset var
			reliability_j.clear();
			diff_sq_sum = 0.0;
			write_flag = true;

			auto total_duration = 0;

			for (int j = 0; j < constants::kRepeatForVariance; j++) {
				std::cout << j << "th iteration" << std::endl;

				// Start time
				auto start = std::chrono::high_resolution_clock::time_point::max();
				auto finish = std::chrono::high_resolution_clock::time_point::max();
				start = std::chrono::high_resolution_clock::now();
				mm.startMonitoring();

				// Calculate reliability
				Graph simple_graph = graph.simplify(source);
				std::vector<int> e1;
				std::vector<int> e2;
				std::vector<Edge_s_t> e_all;
				std::vector<double> p_all;
				reliability = rss.recursiveStratifiedSampling(simple_graph, simple_graph, k, source, target, std::set<Edge_s_t>(),e1,e2,e_all,p_all);

				// Stop time
				finish = std::chrono::high_resolution_clock::now();
				//auto duration = std::chrono::duration_cast<std::chrono::seconds>(finish - start).count();
				auto duration = std::chrono::duration_cast<std::chrono::milliseconds>(finish - start).count();

				std::cout << "Reliability Estimator, R^ (" << source << ", " << target << ") = " << reliability << std::endl;
				std::cout << "Execution time = " << duration << " ms" << std::endl << std::endl;

				// Add r to vector
				reliability_j.push_back(reliability);
				total_duration += duration;

				if (j== constants::kRepeatForVariance-1) {
					avg_r = ConvergenceHelper::getAvgReliability(reliability_j);
					// Write interim results into csv
					FileIO::appendResultstoFile(k, avg_r, total_duration/constants::kRepeatForVariance, mm.getPeakMemory(), graph.getGraphName() + "_RSS_k_" + std::to_string(i) + ".csv");
					write_flag = false;
				}
				
			}
			
			// Add r to vector of r
			reliability_k.push_back(avg_r);

			// Variance calculation
			avg_r = ConvergenceHelper::getAvgReliability(reliability_j);
			for (int j = 0; j < constants::kRepeatForVariance; j++) {
				auto difference_sq = pow(reliability_j[j] - avg_r, 2);
				diff_sq_sum += difference_sq;
			}
			FileIO::appendResultstoFile(k, diff_sq_sum / (constants::kRepeatForVariance - 1), 0, i, graph.getGraphName() + "_RSS_variance.csv");
		}
		// Calulate avg r
		prev_avg_r = curr_avg_r;
		curr_avg_r = ConvergenceHelper::getAvgReliability(reliability_k);
	}
	mm.stopMonitoring();
}

void Menu::findkLazyPropagation(Graph & graph)
{
	VertexDescr source, target;
	size_t k = 0;	
	double reliability = 0.0;
	std::vector<double> reliability_k, reliability_j;
	double curr_avg_r = 2.0;
	double prev_avg_r = 3.0;
	double avg_r = 0.0;
	double diff_sq_sum = 0.0;
	bool write_flag = true;
	LazyPropagation lp;
	DirectedGraph g = *graph.getGraph();

	// Get the respective source-target pairs list from user input
	std::cout << std::endl << "Reading Source-Target file..." << std::endl;
	std::vector<std::pair<VertexDescr, VertexDescr>> source_target_pairs = FileIO::readSourceTargetFile(FileIO::getFilePath());

	// Start up Memory Monitor daemon thread
	MemoryMonitor mm = MemoryMonitor();
	std::thread t1(&MemoryMonitor::updatePeakMemory, std::ref(mm));
	t1.detach();

	while (fabs(curr_avg_r - prev_avg_r) > constants::kReliabilityThreshold && k < constants::kMaximumRound) {
		// Step up k
		k += constants::kKStepUp;
		std::cout << std::endl << "k = " << k << std::endl;

		// Reset var
		reliability_k.clear();

		for (size_t i = 0; i < source_target_pairs.size(); i++) {
			// Set source-target pair
			source = source_target_pairs[i].first;
			target = source_target_pairs[i].second;

			// Reset var
			reliability_j.clear();
			diff_sq_sum = 0.0;
			write_flag = true;
			auto total_duration = 0;

			for (int j = 0; j < constants::kRepeatForVariance; j++) {
				std::cout << j << "th iteration" << std::endl;

				// Start time
				auto start = std::chrono::high_resolution_clock::time_point::max();
				auto finish = std::chrono::high_resolution_clock::time_point::max();
				start = std::chrono::high_resolution_clock::now();
				mm.startMonitoring();

				// Calculate reliability
				reliability = lp.lazySample(source, target, g, k);

				// Stop time
				finish = std::chrono::high_resolution_clock::now();
				//auto duration = std::chrono::duration_cast<std::chrono::seconds>(finish - start).count();
				auto duration = std::chrono::duration_cast<std::chrono::milliseconds>(finish - start).count();

				std::cout << "Reliability Estimator, R^ (" << source << ", " << target << ") = " << reliability << std::endl;
				std::cout << "Execution time = " << duration << " ms" << std::endl << std::endl;

				// Add r to vector
				reliability_j.push_back(reliability);
				total_duration += duration;

				if (j == constants::kRepeatForVariance - 1) {
					// Write interim results into csv
					avg_r = ConvergenceHelper::getAvgReliability(reliability_j);
					FileIO::appendResultstoFile(k, avg_r, total_duration/constants::kRepeatForVariance, mm.getPeakMemory(), graph.getGraphName() + "_LP_k_" + std::to_string(i) + ".csv");
					write_flag = false;
				}
				
			}
			// Add r to vector of r
			reliability_k.push_back(avg_r);

			// Variance calculation
			avg_r = ConvergenceHelper::getAvgReliability(reliability_j);
			for (int j = 0; j < constants::kRepeatForVariance; j++) {
				auto difference_sq = pow(reliability_j[j] - avg_r, 2);
				diff_sq_sum += difference_sq;
			}
			FileIO::appendResultstoFile(k, diff_sq_sum / (constants::kRepeatForVariance - 1), 0, i, graph.getGraphName() + "_LP_variance.csv");
		}
		// Calulate avg r
		prev_avg_r = curr_avg_r;
		curr_avg_r = ConvergenceHelper::getAvgReliability(reliability_k);
	}
	mm.stopMonitoring();
}

// Use FWD with w=2
void Menu::findkProbTree()
{
	std::cout << "Input dir of Index: " << std::endl << std::flush;
	// Get dir of index
	std::string file_name_decomp(FileIO::getFilePath());
	TreeDecomposition decomp(file_name_decomp);
	Bag* root_bag = decomp.get_root();

	std::cout << std::endl << "Reading Source-Target file..." << std::endl;
	std::vector<std::pair<VertexDescr, VertexDescr>> source_target_pairs = FileIO::readSourceTargetFile(FileIO::getFilePath());

	// Get graph name
	std::cout << "Graph name: ";
	std::string graph_name;
	std::cin >> graph_name;
	std::cout << std::endl;

	int samples = 0;
	NodeIdType source, target;
	int pairs = 0;
	ShortestPathSampler sampler;
	double reliability = 0.0;
	std::vector<double> reliability_k, reliability_j;
	double avg_r = 0.0;
	double diff_sq_sum = 0.0;
	bool write_flag = true;

	// Start up Memory Monitor daemon thread
	MemoryMonitor mm = MemoryMonitor();
	std::thread t1(&MemoryMonitor::updatePeakMemory, std::ref(mm));
	t1.detach();

	while (samples < constants::kMaximumRound) {
		// Step up k
		samples += constants::kKStepUp;
		std::cout << std::endl << "k = " << samples << std::endl;

		// Reset var
		reliability_k.clear();

		for (size_t i = 0; i < source_target_pairs.size(); i++) {
			source = source_target_pairs[i].first;
			target = source_target_pairs[i].second;

			// Reset var
			reliability_j.clear();
			diff_sq_sum = 0.0;
			write_flag = true;

			for (int j = 0; j < constants::kRepeatForVariance; j++) {
				std::cout << j << "th iteration" << std::endl;

				// Start time
				auto start = std::chrono::high_resolution_clock::time_point::max();
				auto finish = std::chrono::high_resolution_clock::time_point::max();
				start = std::chrono::high_resolution_clock::now();
				mm.startMonitoring();

				NodeIdType src, tgt;
				src = tgt = -1;
				bool good_tree = true;
				if (!root_bag->has_node(source)) src = source;
				if (!root_bag->has_node(target)) tgt = target;
				int hit_bags = 0;
				try {
					if ((src != -1) || (tgt != -1)) hit_bags = decomp.redo_computations(src, tgt);
				}
				catch (int e) {
					std::cerr << "exception " << e << "caught in " << src << "->" << \
						tgt << " - skipping" << std::endl;
					good_tree = false;
				}
				std::cout << "s-t pairs: " << source << "\t" << target << std::endl << std::flush;
				DistanceDistribution *dist = nullptr;
				if (good_tree) {
					try {
						dist = sampler.sample(root_bag, source, target, samples);
					}
					catch (int e) {
						std::cerr << "exception " << e << "caught in " << src << "->"\
							<< tgt << " - skipping" << std::endl;
						dist = new DistanceDistribution();
					}
				}
				else
					dist = new DistanceDistribution();
				reliability = sampler.get_reached() / (double)samples;

				// Stop time
				finish = std::chrono::high_resolution_clock::now();
				//auto duration = std::chrono::duration_cast<std::chrono::seconds>(finish - start).count();
				auto duration = std::chrono::duration_cast<std::chrono::milliseconds>(finish - start).count();

				std::cout << "Reliability Estimator, R^ (" << source << ", " << target << ") = " << reliability << std::endl;
				std::cout << "Execution time = " << duration << " ms" << std::endl << std::endl;

				if (write_flag) {
					// Write interim results into csv
					FileIO::appendResultstoFile(samples, reliability, duration, mm.getPeakMemory(), graph_name + "_ProbTree_k_" + std::to_string(i) + ".csv");
					write_flag = false;
				}
				
				// Add r to vector
				reliability_j.push_back(reliability);

				delete dist;
			}

			// Variance calculation
			avg_r = ConvergenceHelper::getAvgReliability(reliability_j);
			for (int j = 0; j < constants::kRepeatForVariance; j++) {
				auto difference_sq = pow(reliability_j[j] - avg_r, 2);
				diff_sq_sum += difference_sq;
			}
			FileIO::appendResultstoFile(samples, diff_sq_sum / (constants::kRepeatForVariance - 1), 0, i, graph_name + "_ProbTree_variance.csv");
		}
	}
	mm.stopMonitoring();
}

/*
 * Contains debug commands
 */
void Menu::debugCommand(Graph & graph)
{
	//Menu::calculateOptimalK(graph);
	//graph.getBFSKDistanceAwayVertices(2, 1257, *graph.getGraph());
	//graph.getUniquePathsFromSource(0, 5, *graph.getGraph());
	//Menu::findKMonteCarlo(graph, 98);
	//graph.getUniquePathsFromSource(0, 5, *graph.getGraph());
	//BFSSharing(graph, 10);
	//MonteCarloSamplingDFSSharing(graph, 10);
	/*double p = 0.001;
	std::cout << std::endl;
	std::cout << "Given p =" << p << std::endl;
	for (int i = 0; i < 2000; i++) {
		std::cout << Randomiser::geometric_dist(p) << std::endl;
	}*/
	graph.getBFSKDistanceAwayVertices(6, 0, *graph.getGraph());
}

void Menu::findKBFSSharing(Graph & graph)
{
	VertexDescr source, target;
	boost::dynamic_bitset<> bit_vector;
	size_t k = 0;
	double reliability = 0.0;
	std::vector<double> reliability_k, reliability_j;
	double curr_avg_r = 2.0;
	double prev_avg_r = 3.0;
	double avg_r = 0.0;
	double diff_sq_sum = 0.0;
	bool write_flag = true;

	std::cout << "Intialising BFS Sharing" << std::endl;
	std::cout << "Reading BFS Index..." << std::endl;
	std::cout << "> Choose the Dir containing BFS Indices <" << std::endl;
	std::string file_path_a = FileIO::getFilePath();
	std::string file_path_b = ".txt";

	// Get the respective source-target pairs list from user input
	std::cout << std::endl << "Reading Source-Target file..." << std::endl;
	std::vector<std::pair<VertexDescr, VertexDescr>> source_target_pairs = FileIO::readSourceTargetFile(FileIO::getFilePath());

	MemoryMonitor mm = MemoryMonitor();
	std::thread t1(&MemoryMonitor::updatePeakMemory, std::ref(mm));
	t1.detach();

	while (fabs(curr_avg_r - prev_avg_r) > constants::kReliabilityThreshold && k < constants::kMaximumRound) {
		// Step up k
		k += constants::kKStepUp;
		std::cout << std::endl << "k = " << k << std::endl;

		// Reset var
		reliability_k.clear();

		for (size_t i = 0; i < source_target_pairs.size(); i++) {
			// Set source-target pair
			source = source_target_pairs[i].first;
			target = source_target_pairs[i].second;

			// Reset var
			reliability_j.clear();
			diff_sq_sum = 0.0;
			write_flag = true;

			for (int j = 0; j < constants::kRepeatForVariance; j++) {
				std::cout << j << "th iteration" << std::endl;

				// Start time
				auto start_load = std::chrono::high_resolution_clock::time_point::max();
				auto finish_load = std::chrono::high_resolution_clock::time_point::max();
				start_load = std::chrono::high_resolution_clock::now();
				mm.startMonitoring();

				// Load BFS Index File
				BFSSharing bfs_sharing(file_path_a + "/" + std::to_string(j) + "/" + std::to_string(k) + file_path_b);

				// Stop time
				finish_load = std::chrono::high_resolution_clock::now();
				auto duration_load = std::chrono::duration_cast<std::chrono::milliseconds>(finish_load - start_load).count();

				std::cout << "Execution time = " << duration_load << " ms" << std::endl << std::endl;
				if (write_flag) {
					FileIO::appendResultstoFile(k, 0.0, duration_load, mm.getPeakMemory(), graph.getGraphName() + "_BFSSharing_load_time.csv");
				}

				// Start time
				auto start = std::chrono::high_resolution_clock::time_point::max();
				auto finish = std::chrono::high_resolution_clock::time_point::max();
				start = std::chrono::high_resolution_clock::now();
				mm.startMonitoring();

				// Calculate reliability
				bit_vector = bfs_sharing.getFinalBitVector(graph, source, target);
				reliability = bit_vector.count() / (double)k;

				// Stop time
				finish = std::chrono::high_resolution_clock::now();
				auto duration = std::chrono::duration_cast<std::chrono::milliseconds>(finish - start).count();

				std::cout << "Reliability Estimator, R^ (" << source << ", " << target << ") = " << reliability << std::endl;
				std::cout << "Execution time = " << duration << " ms" << std::endl << std::endl;

				if (write_flag) {
					// Write interim results into csv
					FileIO::appendResultstoFile(k, reliability, duration, mm.getPeakMemory(), graph.getGraphName() + "_BFSSharing_k_" + std::to_string(i) + ".csv");
					write_flag = false;
				}

				// Add r to vector
				reliability_j.push_back(reliability);
			}
			// Add r to vector of r
			reliability_k.push_back(reliability);

			// Variance calculation
			avg_r = ConvergenceHelper::getAvgReliability(reliability_j);
			for (int j = 0; j < constants::kRepeatForVariance; j++) {
				auto difference_sq = pow(reliability_j[j] - avg_r, 2);
				diff_sq_sum += difference_sq;
			}
			FileIO::appendResultstoFile(k, diff_sq_sum / (constants::kRepeatForVariance - 1), 0, i, graph.getGraphName() + "_BFSSharing_variance.csv");

		}
		// Calulate avg r
		prev_avg_r = curr_avg_r;
		curr_avg_r = ConvergenceHelper::getAvgReliability(reliability_k);
	}
	mm.stopMonitoring();
}
