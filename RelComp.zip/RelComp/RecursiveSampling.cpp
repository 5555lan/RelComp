#include "RecursiveSampling.h"


// Gets all out edges of a vertex v
std::queue<Edge_s_t> RecursiveSampling::getOutgoingNeighbours(VertexDescr v)
{
	std::queue<Edge_s_t> i;
	// Check if there are any out edges from w
	if (boost::out_degree(v, dg) != 0) {
		OutEdgeIter out_i, out_end;
		for (boost::tie(out_i, out_end) = boost::out_edges(v, dg); out_i != out_end; ++out_i) {
			i.push(std::make_pair(v, boost::target(*out_i, dg)));
		}
	}
	else {
		// Empty queue
	}
	return i;
}

RecursiveSampling::RecursiveSampling()
{
}

RecursiveSampling::RecursiveSampling(Graph graph)
{
	reference_graph = graph;
	dg = *graph.getGraph();
	weights = boost::get(boost::edge_weight_t(), dg);
}

double RecursiveSampling::findReliability_RB(Graph& g, std::set<Edge_s_t> e1, std::set<Edge_s_t> e2, std::stack<VertexDescr> sv, std::stack<std::queue<Edge_s_t>> si, size_t n)
{
	std::pair<Edge_s_t, bool> edge_bool_pair;
	Edge_s_t e;
	//std::cout << "-> " << sv.top() << std::endl;	// Debug
	// Apply non-recursive sampling estimate if n <= threshold
	if (n <= constants::kRecursiveSamplingThreshold) {		
		// Use Monte Carlo
		int reliability = 0;
		if (n == 0) {
			n = 1;
		}
		MonteCarloBFS g_j = MonteCarloBFS(*g.getGraph());
		//std::cout << "n = " << n << std::endl;
		for (size_t j = 0; j < n; j++) {
			// Compute reliability of Gj
			// And update reliability
			reliability += g_j.run(sv.top(), t);
		}
		return reliability / (double) n;
	}
	// Return 1 if E1 contains a d-path from s to t
	if (sv.top() == t) {
		//std::cout << "Leaf node found: Return 1" << std::endl;	// Debug
		return 1;
	}
	edge_bool_pair = nextEdge(e1, e2, sv, si);
	// Return 0 if E2 contains a d-cut from s to t
	if (edge_bool_pair.second == false) {
		//std::cout << "Leaf node found: Return 0" << std::endl;	// Debug
		return 0;
	}
	e = edge_bool_pair.first;
	// E1 U e
	std::set<Edge_s_t> e1_u_e(e1);
	e1_u_e.insert(e);
	// E2 U e
	std::set<Edge_s_t> e2_u_e(e2);
	e2_u_e.insert(e);
	Graph g_e2 = g;
	remove_edge(edge(e.first, e.second, *g_e2.getGraph()).first, *g_e2.getGraph());
	// Sv push w
	VertexDescr w = e.second;
	std::stack<VertexDescr> sv_w(sv);
	sv_w.push(w);
	// Si push all outgoing edges
	std::stack<std::queue<Edge_s_t>> si_1(si);
	si_1.push(getOutgoingNeighbours(w));
	// Edge Probability
	double edge_probability = get(weights, boost::edge(sv.top(), w, dg).first);

	return edge_probability * findReliability_RB(g, e1_u_e, e2, sv_w, si_1, std::floor(n*edge_probability)) + (1 - edge_probability)*findReliability_RB(g_e2, e1, e2_u_e, sv, si, n - std::floor(n*edge_probability));
}
double RecursiveSampling::findReliability_RHH(std::set<Edge_s_t> e1, std::set<Edge_s_t> e2, std::stack<VertexDescr> sv, std::stack<std::queue<Edge_s_t>> si, size_t n)
{
	std::pair<Edge_s_t, bool> edge_bool_pair;
	Edge_s_t e;
	//std::cout << "-> " << sv.top() << std::endl;	// Debug
	// Apply non-recursive sampling estimate if n <= threshold
	if (n <= constants::kRecursiveSamplingThreshold) {
		//std::cout << "Entering RHH..." << std::endl;
		if (n == 0) {
			return 0;
		}
		size_t rhh = 0;
		for (size_t i = 0; i < n; i++) {				// Run n times
			rhh += samplingR(e1, e2, sv.top(), 1, 1);	// Returns 1 or 0
		}
		return rhh / (double)n;
	}
	// Return 1 if E1 contains a d-path from s to t
	if (sv.top() == t) {
		//std::cout << "Leaf node found: Return 1" << std::endl;	// Debug
		return 1;
	}
	edge_bool_pair = nextEdge(e1, e2, sv, si);
	// Return 0 if E2 contains a d-cut from s to t
	if (edge_bool_pair.second == false) {
		//std::cout << "Leaf node found: Return 0" << std::endl;	// Debug
		return 0;
	}
	e = edge_bool_pair.first;
	// E1 U e
	std::set<Edge_s_t> e1_u_e(e1);
	e1_u_e.insert(e);
	// E2 U e
	std::set<Edge_s_t> e2_u_e(e2);
	e2_u_e.insert(e);
	// Sv push w
	VertexDescr w = e.second;
	std::stack<VertexDescr> sv_w(sv);
	sv_w.push(w);
	// Si push all outgoing edges
	std::stack<std::queue<Edge_s_t>> si_1(si);
	si_1.push(getOutgoingNeighbours(w));
	// Edge Probability
	double edge_probability = get(weights, boost::edge(sv.top(), w, dg).first);

	return edge_probability * findReliability_RHH(e1_u_e, e2, sv_w, si_1, std::floor(n*edge_probability)) + (1 - edge_probability)*findReliability_RHH(e1, e2_u_e, sv, si, n - std::floor(n*edge_probability));
}
// Returns the initial stack of sv and si given a source vertex
std::pair<std::stack<VertexDescr>, std::stack<std::queue<Edge_s_t>>> RecursiveSampling::getInitStack(VertexDescr source)
{
	std::stack<VertexDescr> sv;
	std::stack<std::queue<Edge_s_t>> si;
	sv.push(source);
	si.push(getOutgoingNeighbours(source));
	return std::make_pair(sv,si);
}
// return a pair of edge and bool. bool == false if no edges found
std::pair<Edge_s_t, bool> RecursiveSampling::nextEdge(std::set<Edge_s_t> e1, std::set<Edge_s_t> e2, std::stack<VertexDescr> sv, std::stack<std::queue<Edge_s_t>> si)
{
	VertexDescr v, v_i;
	std::queue<Edge_s_t> neighbours;
	Edge_s_t e;
	bool pop_flag = true;	// Only pop si and sv if true
	if (!sv.empty()) {
		pop_flag = true;
		v = sv.top();
		while (!si.top().empty()) {
			v_i = si.top().front().second;
			e = si.top().front();
			si.top().pop();
			// Check that e does not belong in e2
			if (e2.count(e) == 0) {
				// Check that e belongs in e1
				if (e1.count(e) != 0) {
					sv.push(v_i);
					si.push(getOutgoingNeighbours(v_i));
					pop_flag = false;
					break;
				}
				else {
					return std::make_pair(e, true);
				}
			}
		}
		if (pop_flag) {
			sv.pop();
			si.pop();
		}
	}
	// No edge found
	return std::make_pair(std::make_pair(-1, -1), false);
}

void RecursiveSampling::setTarget(VertexDescr target)
{
	t = target;
}

// RHH
double RecursiveSampling::samplingR(std::set<Edge_s_t> e1, std::set<Edge_s_t> e2, VertexDescr v, double pr, double q)
{
	std::pair<Edge_s_t, bool> edge_bool_pair;
	Edge_s_t e;
	std::stack<VertexDescr> sv;
	std::stack<std::queue<Edge_s_t>> si;
	double edge_probability;
	VertexDescr w;
	// Return if E1 contains a d-path from s to t
	if (v == t) {
		return pr / q;
	}
	// Find next edge
	sv.push(v);
	si.push(getOutgoingNeighbours(v));
	edge_bool_pair = nextEdge(e1, e2, sv, si);
	// Return 0 if E2 contains a d-cut from s to t
	if (edge_bool_pair.second == false) {
		//std::cout << "Leaf node found: Return 0" << std::endl;	// Debug
		return 0;
	}
	e = edge_bool_pair.first;
	w = e.second;
	// Get edge probability
	edge_probability = get(weights, boost::edge(v, w, dg).first);
	// E1 U e
	std::set<Edge_s_t> e1_u_e(e1);
	e1_u_e.insert(e);
	// E2 U e
	std::set<Edge_s_t> e2_u_e(e2);
	e2_u_e.insert(e);
	// Check if exists
	if (Randomiser::getProbability() < edge_probability) {
		return samplingR(e1_u_e, e2, w, edge_probability*pr, edge_probability*q);
	}
	else {
		return samplingR(e1, e2_u_e, w, (1 - edge_probability)*pr, (1 - edge_probability)*q);
	}
}


RecursiveSampling::~RecursiveSampling()
{
}
